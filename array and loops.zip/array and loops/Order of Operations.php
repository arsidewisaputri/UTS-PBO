<?php
//arsi_dewi_saputri
//2255201002
//semester_3
// Write your code below: 
  
  echo 94 - 4.25 + 7 - 23.50 * 1.2 + 20 / 4;

