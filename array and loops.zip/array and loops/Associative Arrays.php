<?php
//arsi_dewi_saputri
//2255201002
//semester_3
namespace Codecademy;
$my_array = ["panda" => "very cute", "lizard" => "cute", "cockroach" => "not very cute"];

// Write your code below:
$about_me = array(
    "fullname" => "Aisle Nevertell",
    "social" => 123456789
);