<?php
//arsi_dewi_saputri
//2255201002
//semester_3
namespace Codecademy;
$september_hits = ["The Sixth Sense" => 22896967,
"Stigmata" => 18309666,
"Blue Streak" => 19208806 ,
"Double Jeopardy" => 19208806];
// Write your code below:
echo implode(",",$september_hits );