<?php
//arsi_dewi_saputri
//2255201002
//semester_3
// Write your code below:
$age = 11;
echo $age;
echo "\n";
$movie_rating = 3.2;
echo $movie_rating;
  