<?php
//arsi_dewi_saputri
//2255201002
//semester_3
/* Imagine a lot of code here */  
  $very_bad_unclear_name = "15 chicken wings";
  $order =& $very_bad_unclear_name;

// Write your code here:
$order .= "makan";
echo $sentence;



    
  // Don't change the line below
  echo "\nYour order is: $very_bad_unclear_name.";


