<?php
//arsi_dewi_saputri
//2255201002
//semester_3
// Write your code below:
echo 8.2 + 3.8;
  

