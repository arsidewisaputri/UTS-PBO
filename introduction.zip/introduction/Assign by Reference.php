<?php
//arsi_dewi_saputri
//2255201002
//semester_3
/* Imagine a lot of code here */  
  $very_bad_unclear_name = "15 chicken wings";
  $order =& $very_bad_unclear_name;

// Write your code here:
echo "\nyour order is: $very_bad_unclear_name.";

