<?php
//arsi_dewi_saputri
//2255201002
//semester_3
  echo "I'm going on a picnic!";

  $sentence = "\nI'm going on a picnic, and I'm taking apples";

$sentence .= ", bobo";
$sentence .=", cicak";
  echo $sentence;


// Write your code below:





