<?php
//arsi_dewi_saputri
//2255201002
//semester_3
$movie = "the nun";
$old_favorite = $movie;
// Add your code here:



 echo "I'm a fickle person, my favorite movie used to be $movie.";
  
// Add a statement here:
 $movie = "curiga"; 
  
  echo "\nBut now my favorite is $old_favorite.";
  
// Add a statement below:


  



