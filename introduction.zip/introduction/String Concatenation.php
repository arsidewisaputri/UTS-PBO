<?php
//arsi_dewi_saputri
//2255201002
//semester_3
// Write your code below:   


  //echo "\nMy name is:" 

echo "Code" . "cademy";
echo "\nMy name is:" . " arsi dewi saputri";
echo "\n" . "tur" . "duck" . "en";

 
  
  


