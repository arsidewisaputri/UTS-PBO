<?php
//arsi_dewi_saputri
//2255201002
//semester_3
//write your code below:
echo "Hello, World!"; // Prints: My first string

  