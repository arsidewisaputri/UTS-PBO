<?php
//arsi_dewi_saputri
//2255201001
//semester_3
// Write your code below:
$savings = 800;
$bike_cost = 75;
$savings = $savings - $bike_cost;
echo $savings; // Prints: 725


  