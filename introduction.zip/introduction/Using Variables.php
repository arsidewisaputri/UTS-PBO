<?php
//arsi_dewi_saputri
//2255201002
//semester_3
// Write your code below:
 $name = "Hello I am a variable!";
$language = "Oh hi. I'm also a variable.";
$string = "variables";
echo "I love concatenating " . $name;
$food = "burgers";
echo "\nI love " . $language;


 
  
  
  


